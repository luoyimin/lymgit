import loadImage from './loadImage';
import preloadImages from './preloadImages';

export default {
  loadImage,
  preloadImages,
};
